export default function Home() {
  return (
    <main style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>JaipurCircle</h1>
      <p>Home page is live ✅</p>
    </main>
  );
}
