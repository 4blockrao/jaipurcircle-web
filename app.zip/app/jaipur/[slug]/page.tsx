// app/jaipur/[slug]/page.tsx
import Link from "next/link";
import { notFound } from "next/navigation";
import { supabaseServer } from "@/lib/supabaseServer";

export const runtime = "nodejs";
export const revalidate = 600;

type LocalityRow = {
  id: string;
  slug: string;
  name?: string | null;
  title?: string | null;
  description?: string | null;
  updated_at?: string | null;
};

export default async function JaipurLocalityPage({
  params,
}: {
  params: { slug?: string };
}) {
  const slug = params?.slug;
  if (!slug) return notFound();

  // Keep select minimal + schema-safe.
  // If your localities table has more fields, we can extend later safely.
  const { data, error } = await supabaseServer
    .from("localities")
    .select("id,slug,name,title,description,updated_at")
    .eq("slug", slug)
    .maybeSingle<LocalityRow>();

  if (error || !data) return notFound();

  const name = (data.name || data.title || data.slug).toString();

  return (
    <main className="mx-auto max-w-4xl px-4 py-10">
      <nav className="mb-4 text-sm text-neutral-400">
        <Link href="/" className="hover:underline">
          Home
        </Link>{" "}
        ›{" "}
        <Link href="/jaipur" className="hover:underline">
          Jaipur
        </Link>{" "}
        › {name}
      </nav>

      <h1 className="text-4xl font-semibold">{name}</h1>
      <p className="mt-3 text-neutral-300">
        Practical locality guide for <b>{name}</b> — context, landmarks, and what to do nearby.
      </p>

      <section className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-5">
        <h2 className="text-lg font-medium">About {name}</h2>
        <p className="mt-2 whitespace-pre-wrap text-neutral-300 leading-relaxed">
          {data.description?.trim()
            ? data.description
            : "We’re building this locality page. Soon it will include quick context, nearby hotspots, safety + commute notes, and curated events."}
        </p>
      </section>

      <section className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-5">
        <h2 className="text-lg font-medium">Explore</h2>
        <ul className="mt-3 list-disc pl-5 text-neutral-300 space-y-1">
          <li>
            <Link className="underline" href="/events">
              Browse Jaipur events
            </Link>
          </li>
          <li>
            <Link className="underline" href="/localities">
              Browse all localities
            </Link>
          </li>
        </ul>
      </section>

      <div className="mt-10 text-xs text-neutral-500">
        FILE-FINGERPRINT: jaipur-locality-v1
      </div>
    </main>
  );
}